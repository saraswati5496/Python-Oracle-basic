import cx_Oracle

#create connection
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
print(conn.version)

#create cursor
cur = conn.cursor()

sql_create = """
  create table Person22(
    firstnm varchar2(50),
    city varchar2(50),
    role varchar2(50)
  )
"""

cur.execute(sql_create)
print('Table created')

